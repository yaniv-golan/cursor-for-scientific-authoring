# Claims Log

Use this file to record non-obvious statements and their sources so agent edits stay grounded.

Template entry
- Claim: <what is being asserted>
- Evidence: <quote/paraphrase/summary>
- Source: <citation key or link/DOI>
- Location: <manuscript file/section>
- Notes: <verification or follow-ups>
