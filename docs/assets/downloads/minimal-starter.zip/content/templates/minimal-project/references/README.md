# References Folder

Place your bibliography here (e.g., BibTeX `.bib` or CSL JSON `.json`).
Add any citation style files (`.csl`) used for export.

Tip: Keep `references/` as the source of truth for your citations.
